package com.tudominio.doloreshidalgoturismo01.ui.viewmodel

import com.tudominio.doloreshidalgoturismo01.data.model.PlaceEntity


/**
 * Clase de datos para estadísticas
 */
data class PlaceStatistics(
    val totalPlaces: Int = 0,
    val favoriteCount: Int = 0,
    val categoryCounts: Map<String, Int> = emptyMap(),
    val mostRecentPlace: PlaceEntity? = null
)