package com.educacion.domangame.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * DataStore: Alternativa moderna a SharedPreferences.
 *
 * Usos:
 * - Guardar configuraciones
 * - Último niño que jugó
 * - Nivel de dificultad preferido
 */
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(
    name = "app_preferences"
)

class PreferencesManager(private val context: Context) {

    companion object {
        val LAST_CHILD_NAME = stringPreferencesKey("last_child_name")
        val DIFFICULTY_LEVEL = intPreferencesKey("difficulty_level")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
    }

    val lastChildName: Flow<String?> = context.dataStore.data
        .map { preferences ->
            preferences[LAST_CHILD_NAME]
        }

    suspend fun saveLastChildName(name: String) {
        context.dataStore.edit { preferences ->
            preferences[LAST_CHILD_NAME] = name
        }
    }

    val soundEnabled: Flow<Boolean> = context.dataStore.data
        .map { preferences ->
            preferences[SOUND_ENABLED] ?: true
        }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[SOUND_ENABLED] = enabled
        }
    }
}