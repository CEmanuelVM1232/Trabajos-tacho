package com.educacion.domangame.ui.screens

import android.util.Log
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.viewmodel.compose.viewModel
import com.educacion.domangame.data.Word
import com.educacion.domangame.ui.DragAndDropState
import com.educacion.domangame.ui.components.DraggableWordCard
import com.educacion.domangame.ui.components.DropTargetImage
import com.educacion.domangame.ui.rememberDragAndDropState
import com.educacion.domangame.viewmodel.GameState
import com.educacion.domangame.viewmodel.GameViewModel

/**
 * Pantalla principal del juego.
 *
 * Arquitectura:
 * - Usa MVVM: ViewModel gestiona estado, UI solo renderiza
 * - Estado elevado: El estado vive en ViewModel, no en componentes
 * - Composición sobre herencia: Pequeños componentes reutilizables
 */
@Composable
fun GameScreen(
    childName: String,
    onGameFinished: (Int, Int) -> Unit,
    viewModel: GameViewModel = viewModel()
) {
    val gameState by viewModel.gameState.collectAsState()
    val dragState = rememberDragAndDropState()

    var targetPositions by remember {
        mutableStateOf<Map<Int, Pair<Offset, IntSize>>>(emptyMap())
    }

    // AGREGAR: Log del estado
    LaunchedEffect(gameState) {
        Log.d("GameScreen", "Estado actual: ${gameState::class.simpleName}")
    }

    LaunchedEffect(Unit) {
        Log.d("GameScreen", "Iniciando juego para: $childName")
        viewModel.startNewGame(childName)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5))
    ) {
        when (val state = gameState) {
            is GameState.Loading -> {
                LoadingScreen()
                // AGREGAR: Log
                Log.d("GameScreen", "Mostrando pantalla de carga")
            }

            is GameState.Playing -> {
                Log.d("GameScreen", "Mostrando juego con ${state.words.size} palabras")
                PlayingScreen(
                    state = state,
                    dragState = dragState,
                    targetPositions = targetPositions,
                    onTargetPositionCalculated = { wordId, position, size ->
                        targetPositions = targetPositions + (wordId to (position to size))
                    },
                    onWordDropped = { wordId ->
                        val hoveredTargetId = findHoveredTarget(
                            dragState.dragPosition,
                            dragState.draggedItemSize,
                            targetPositions
                        )

                        if (hoveredTargetId != null) {
                            viewModel.checkMatch(wordId, hoveredTargetId)
                        }
                    }
                )
            }

            is GameState.Finished -> {
                Log.d("GameScreen", "Juego terminado: ${state.correctCount}/${state.totalCount}")
                onGameFinished(state.correctCount, state.totalCount)
            }
        }
    }
}

@Composable
private fun LoadingScreen() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(48.dp),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Preparando el juego...",
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
    }
}

@Composable
private fun PlayingScreen(
    state: GameState.Playing,
    dragState: DragAndDropState,
    targetPositions: Map<Int, Pair<Offset, IntSize>>,
    onTargetPositionCalculated: (Int, Offset, IntSize) -> Unit,
    onWordDropped: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Título
        Text(
            text = "Arrastra las palabras a sus imágenes",
            fontSize = 24.sp,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        // Grid de imágenes (targets)
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(state.words) { word ->
                val isMatched = state.matches.containsKey(word.id)
                val isHovered = dragState.isDragging &&
                        isPositionOverTarget(
                            dragState.dragPosition,
                            dragState.draggedItemSize,
                            targetPositions[word.id]
                        )

                DropTargetImage(
                    word = word,
                    isHovered = isHovered,
                    isMatched = isMatched,
                    isIncorrect = false, // TODO: implementar detección de error
                    onPositionCalculated = { position, size ->
                        onTargetPositionCalculated(word.id, position, size)
                    }
                )
            }
        }

        Divider()

        // Fila de palabras arrastrables
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)
        ) {
            state.shuffledWords.forEach { word ->
                val isMatched = state.matches.containsKey(word.id)
                val isDragging = dragState.draggedItemId == word.id

                DraggableWordCard(
                    word = word,
                    isMatched = isMatched,
                    isDragging = isDragging,
                    onDragStart = { position, size ->
                        dragState.startDragging(word.id, size, position)
                    },
                    onDrag = { dragAmount ->
                        dragState.updateDragPosition(
                            dragState.dragPosition + dragAmount
                        )
                    },
                    onDragEnd = {
                        onWordDropped(word.id)
                        dragState.stopDragging()
                    }
                )
            }
        }
    }

    // Tarjeta flotante mientras se arrastra
    if (dragState.isDragging) {
        FloatingDragCard(
            dragState = dragState,
            word = state.words.find { it.id == dragState.draggedItemId }
        )
    }
}

/**
 * Tarjeta que sigue al dedo del usuario mientras arrastra.
 *
 * Analogía: Como la sombra de tu mano cuando mueves un objeto físico.
 */
@Composable
private fun FloatingDragCard(
    dragState: DragAndDropState,
    word: Word?
) {
    if (word == null) return

    Box(
        modifier = Modifier
            .offset(
                x = (dragState.dragPosition.x /
                        LocalDensity.current.density).dp,
                y = (dragState.dragPosition.y /
                        LocalDensity.current.density).dp
            )
            .zIndex(1000f) // Siempre encima de todo
    ) {
        Card(
            modifier = Modifier.size(width = 140.dp, height = 80.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.9f)
            )
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = word.text,
                    fontSize = 28.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }
}

/**
 * Función de utilidad para detectar colisiones.
 *
 * Matemáticas simples: Verifica si dos rectángulos se superponen.
 *
 * Analogía: Como detectar si dos coches chocaron mirando
 * si sus posiciones en el mapa se superponen.
 */
private fun isPositionOverTarget(
    dragPosition: Offset,
    dragSize: IntSize,
    targetInfo: Pair<Offset, IntSize>?
): Boolean {
    if (targetInfo == null) return false

    val (targetPosition, targetSize) = targetInfo

    // Crear rectángulos
    val dragRect = Rect(
        left = dragPosition.x,
        top = dragPosition.y,
        right = dragPosition.x + dragSize.width,
        bottom = dragPosition.y + dragSize.height
    )

    val targetRect = Rect(
        left = targetPosition.x,
        top = targetPosition.y,
        right = targetPosition.x + targetSize.width,
        bottom = targetPosition.y + targetSize.height
    )

    // Verificar superposición (al menos 50% para evitar falsos positivos)
    return dragRect.overlaps(targetRect)
}

private fun findHoveredTarget(
    dragPosition: Offset,
    dragSize: IntSize,
    targetPositions: Map<Int, Pair<Offset, IntSize>>
): Int? {
    return targetPositions.entries.firstOrNull { (_, targetInfo) ->
        isPositionOverTarget(dragPosition, dragSize, targetInfo)
    }?.key
}