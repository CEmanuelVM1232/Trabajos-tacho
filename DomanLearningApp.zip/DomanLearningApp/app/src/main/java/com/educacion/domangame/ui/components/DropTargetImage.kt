package com.educacion.domangame.ui.components

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.educacion.domangame.data.Word
import com.educacion.domangame.utils.ImageHelper

/**
 * Zona donde se pueden soltar las palabras (target).
 *
 * Analogía: Como una caja con el contorno de una pieza de rompecabezas.
 * El niño debe arrastrar la pieza correcta a su lugar.
 *
 * Feedback visual:
 * - Borde brillante cuando una tarjeta está cerca
 * - Check verde cuando se empareja correctamente
 * - Animación de error si es incorrecto
 */
@Composable
fun DropTargetImage(
    word: Word,
    isHovered: Boolean,
    isMatched: Boolean,
    isIncorrect: Boolean,
    onPositionCalculated: (Offset, IntSize) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Animación de shake cuando es incorrecto
    var shake by remember { mutableStateOf(false) }
    val shakeOffset by animateFloatAsState(
        targetValue = if (shake) 10f else 0f,
        animationSpec = repeatable(
            iterations = 3,
            animation = tween(50),
            repeatMode = RepeatMode.Reverse
        ),
        finishedListener = { shake = false },
        label = "shake_animation"
    )

    // Activar shake cuando hay error
    LaunchedEffect(isIncorrect) {
        if (isIncorrect) {
            shake = true
        }
    }

    // Color del borde según estado
    val borderColor by animateColorAsState(
        targetValue = when {
            isMatched -> Color(0xFF4CAF50) // Verde éxito
            isHovered -> Color(0xFF2196F3) // Azul hover
            isIncorrect -> Color(0xFFF44336) // Rojo error
            else -> Color.LightGray
        },
        label = "border_color"
    )

    val borderWidth by animateDpAsState(
        targetValue = if (isHovered || isMatched) 4.dp else 2.dp,
        label = "border_width"
    )

    Box(
        modifier = modifier
            .size(160.dp)
            .offset(x = shakeOffset.dp)
            .onGloballyPositioned { coordinates ->
                onPositionCalculated(
                    coordinates.positionInRoot(),
                    coordinates.size
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(
                        width = borderWidth,
                        color = borderColor,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .clip(RoundedCornerShape(16.dp))
            ) {
                // Usar placeholder de colores si no existe la imagen
                val placeholderColors = mapOf(
                    "mama" to Color(0xFFFF6B9D),
                    "papa" to Color(0xFF4A90E2),
                    "agua" to Color(0xFF50C8F5),
                    "sol" to Color(0xFFFFA726),
                    "gato" to Color(0xFF9C27B0),
                    "perro" to Color(0xFF8D6E63),
                    "casa" to Color(0xFF66BB6A),
                    "pelota" to Color(0xFFEF5350)
                )

                val imageExists = remember(word.imageUrl) {
                    ImageHelper.drawableExists(context, word.imageUrl)
                }

                if (imageExists) {
                    // Cargar imagen real
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(ImageHelper.getImageResourceId(context, word.imageUrl))
                            .crossfade(true)
                            .build(),
                        contentDescription = word.text,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        error = painterResource(
                            id = android.R.drawable.ic_dialog_alert
                        )
                    )
                } else {
                    // Usar placeholder colorido
                    PlaceholderImage(
                        text = word.text,
                        backgroundColor = placeholderColors[word.imageUrl] ?: Color.Gray,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Overlay oscuro cuando está emparejado
                if (isMatched) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.3f))
                    )
                }
            }
        }

        // Ícono de check cuando está correcto
        AnimatedVisibility(
            visible = isMatched,
            enter = scaleIn() + fadeIn(),
            exit = scaleOut() + fadeOut()
        ) {
            Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = "Correcto",
                modifier = Modifier.size(64.dp),
                tint = Color(0xFF4CAF50)
            )
        }
    }
}

/**
 * Helper function para obtener el ID del recurso drawable.
 *
 * En una app real, esto vendría de URLs o una CDN.
 * Aquí usamos recursos locales por simplicidad educativa.
 */
private fun getImageResourceId(context: Context, imageName: String): Int {
    return context.resources.getIdentifier(
        imageName,
        "drawable",
        context.packageName
    )
}