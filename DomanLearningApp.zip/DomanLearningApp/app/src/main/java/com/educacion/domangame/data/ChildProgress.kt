package com.educacion.domangame.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

/**
 * Registra el progreso de cada intento del niño.
 *
 * Analogía: Como el cuaderno de calificaciones del niño,
 * donde guardamos cada ejercicio que resolvió.
 */
@Entity(tableName = "child_progress")
data class ChildProgress(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val childName: String,      // Nombre del niño
    val wordId: Int,            // ID de la palabra practicada
    val isCorrect: Boolean,     // ¿Lo hizo bien?
    val attemptDate: Long = System.currentTimeMillis(), // Fecha del intento
    val timeSpentMs: Long       // Tiempo que tardó en milisegundos
)