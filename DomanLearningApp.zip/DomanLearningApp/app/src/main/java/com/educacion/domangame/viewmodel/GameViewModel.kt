package com.educacion.domangame.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.educacion.domangame.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * ViewModel: Gestiona la lógica de negocio y el estado de la UI.
 *
 * Analogía: Es como el director de una obra de teatro.
 * Los actores (composables) solo actúan, pero el director
 * decide qué escena sigue, cuándo cambiar, etc.
 *
 * Ventajas:
 * - Sobrevive a cambios de configuración (rotación de pantalla)
 * - Separa la lógica de la interfaz
 * - Facilita testing
 */
class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val wordRepository = WordRepository(database.wordDao())
    private val progressRepository = ProgressRepository(database.progressDao())

    private val _gameState = MutableStateFlow<GameState>(GameState.Loading)
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    private val _currentChild = MutableStateFlow("")
    val currentChild: StateFlow<String> = _currentChild.asStateFlow()

    val availableWords: StateFlow<List<Word>> = wordRepository.allWords
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private var isInitialized = false

    init {
        // Inicializar palabras en el constructor
        viewModelScope.launch {
            try {
                Log.d("GameViewModel", "Iniciando inicialización de palabras...")

                // Esperar a que el Flow esté listo
                availableWords
                    .filter { it.isNotEmpty() }
                    .first() // Espera hasta que haya palabras

                isInitialized = true
                Log.d("GameViewModel", "Palabras inicializadas correctamente: ${availableWords.value.size}")

            } catch (e: Exception) {
                Log.e("GameViewModel", "Error inicializando palabras", e)
                // Si hay error, inicializar palabras de ejemplo
                wordRepository.initializeSampleWords()

                // Esperar a que se inserten
                delay(1000)
                isInitialized = true
            }
        }
    }

    /**
     * Configura un nuevo juego con palabras aleatorias.
     * ARREGLADO: Ahora espera a que las palabras estén disponibles.
     */
    fun startNewGame(childName: String, numberOfWords: Int = 4) {
        _currentChild.value = childName

        viewModelScope.launch {
            try {
                Log.d("GameViewModel", "Iniciando nuevo juego para: $childName")

                // Si no está inicializado, esperar
                if (!isInitialized) {
                    Log.d("GameViewModel", "Esperando inicialización...")
                    _gameState.value = GameState.Loading

                    // Inicializar palabras si no existen
                    if (availableWords.value.isEmpty()) {
                        Log.d("GameViewModel", "Base de datos vacía, insertando palabras de ejemplo...")
                        wordRepository.initializeSampleWords()

                        // Esperar a que se inserten
                        availableWords
                            .filter { it.isNotEmpty() }
                            .first()
                    }

                    isInitialized = true
                }

                // Obtener palabras disponibles
                val allWords = availableWords.value
                Log.d("GameViewModel", "Palabras disponibles: ${allWords.size}")

                if (allWords.isEmpty()) {
                    Log.e("GameViewModel", "No hay palabras disponibles después de inicialización")
                    return@launch
                }

                // Seleccionar palabras aleatorias
                val selectedWords = allWords.shuffled().take(numberOfWords)
                Log.d("GameViewModel", "Palabras seleccionadas: ${selectedWords.map { it.text }}")

                // Cambiar a estado Playing
                _gameState.value = GameState.Playing(
                    words = selectedWords,
                    shuffledWords = selectedWords.shuffled(),
                    matches = emptyMap(),
                    startTime = System.currentTimeMillis()
                )

                Log.d("GameViewModel", "Juego iniciado correctamente")

            } catch (e: Exception) {
                Log.e("GameViewModel", "Error iniciando juego", e)
                // Mantener en Loading si hay error
            }
        }
    }

    fun checkMatch(wordId: Int, imageId: Int) {
        val currentState = _gameState.value as? GameState.Playing ?: return

        Log.d("GameViewModel", "Verificando match: word=$wordId, image=$imageId")

        val isCorrect = wordId == imageId
        val newMatches = currentState.matches + (wordId to imageId)

        val allMatched = currentState.words.all { word ->
            newMatches.containsKey(word.id)
        }

        viewModelScope.launch {
            val timeSpent = System.currentTimeMillis() - currentState.startTime

            try {
                progressRepository.recordAttempt(
                    childName = _currentChild.value,
                    wordId = wordId,
                    isCorrect = isCorrect,
                    timeSpentMs = timeSpent
                )
            } catch (e: Exception) {
                Log.e("GameViewModel", "Error guardando progreso", e)
            }

            if (allMatched) {
                val correctMatches = newMatches.count { (wordId, imageId) ->
                    wordId == imageId
                }

                _gameState.value = GameState.Finished(
                    correctCount = correctMatches,
                    totalCount = newMatches.size,
                    timeSpentMs = timeSpent
                )
            } else {
                _gameState.value = currentState.copy(matches = newMatches)
            }
        }
    }

    fun resetGame() {
        _gameState.value = GameState.Loading
    }
}


/**
 * Estados posibles del juego (Máquina de Estados).
 *
 * Analogía: Como un semáforo que solo puede estar en
 * Verde, Amarillo o Rojo. Nunca en dos colores a la vez.
 */
sealed class GameState {
    object Loading : GameState()

    data class Playing(
        val words: List<Word>,
        val shuffledWords: List<Word>,
        val matches: Map<Int, Int>,
        val startTime: Long
    ) : GameState()

    data class Finished(
        val correctCount: Int,
        val totalCount: Int,
        val timeSpentMs: Long
    ) : GameState()
}