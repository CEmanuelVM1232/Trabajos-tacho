package com.educacion.domangame.data

import kotlinx.coroutines.flow.Flow

/**
 * Repository: Capa intermedia entre la base de datos y la interfaz.
 *
 * Analogía: Es como un mesero en un restaurante.
 * La cocina (base de datos) prepara la comida, pero el mesero
 * (repository) es quien te la trae a tu mesa (UI).
 *
 * Ventajas:
 * - Si cambias de base de datos, solo modificas el Repository
 * - Puedes agregar caché o lógica de negocio aquí
 * - Hace el código más testeable
 */
class WordRepository(private val wordDao: WordDao) {

    val allWords: Flow<List<Word>> = wordDao.getAllWords()

    fun getWordsByCategory(category: String): Flow<List<Word>> {
        return wordDao.getWordsByCategory(category)
    }

    fun getWordsByDifficulty(level: Int): Flow<List<Word>> {
        return wordDao.getWordsByDifficulty(level)
    }

    suspend fun insert(word: Word) {
        wordDao.insertWord(word)
    }

    suspend fun insertMultiple(words: List<Word>) {
        wordDao.insertWords(words)
    }

    suspend fun delete(word: Word) {
        wordDao.deleteWord(word)
    }

    /**
     * Método para inicializar palabras de ejemplo.
     * En producción, esto vendría de un servidor o archivo JSON.
     */
    suspend fun initializeSampleWords() {
        val sampleWords = listOf(
            Word(text = "MAMÁ", category = "familia", imageUrl = "mama", difficulty = 1),
            Word(text = "PAPÁ", category = "familia", imageUrl = "papa", difficulty = 1),
            Word(text = "AGUA", category = "bebidas", imageUrl = "agua", difficulty = 1),
            Word(text = "SOL", category = "naturaleza", imageUrl = "sol", difficulty = 1),
            Word(text = "GATO", category = "animales", imageUrl = "gato", difficulty = 1),
            Word(text = "PERRO", category = "animales", imageUrl = "perro", difficulty = 1),
            Word(text = "CASA", category = "lugares", imageUrl = "casa", difficulty = 1),
            Word(text = "PELOTA", category = "juguetes", imageUrl = "pelota", difficulty = 2)
        )
        insertMultiple(sampleWords)
    }
}