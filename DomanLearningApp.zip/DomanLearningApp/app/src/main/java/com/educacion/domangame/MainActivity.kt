package com.educacion.domangame

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.educacion.domangame.ui.screens.GameScreen
import com.educacion.domangame.ui.screens.HomeScreen
import com.educacion.domangame.ui.screens.ResultsScreen
import com.educacion.domangame.ui.theme.DomanLearningAppTheme

/**
 * Activity principal con navegación manual (sin NavController).
 *
 * Para proyectos más grandes, usar Jetpack Navigation Component.
 * Aquí usamos un enfoque simple educativo.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DomanLearningAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

/**
 * Sistema de navegación simple basado en estados.
 *
 * Estados: Home -> Game -> Results -> (loop)
 */
@Composable
fun AppNavigation() {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }
    var currentChildName by remember { mutableStateOf("") }

    when (val screen = currentScreen) {
        is Screen.Home -> {
            HomeScreen(
                onStartGame = { name ->
                    currentChildName = name
                    currentScreen = Screen.Game
                }
            )
        }

        is Screen.Game -> {
            GameScreen(
                childName = currentChildName,
                onGameFinished = { correct, total ->
                    currentScreen = Screen.Results(correct, total)
                }
            )
        }

        is Screen.Results -> {
            ResultsScreen(
                correctCount = screen.correctCount,
                totalCount = screen.totalCount,
                onPlayAgain = {
                    currentScreen = Screen.Game
                },
                onExit = {
                    currentScreen = Screen.Home
                }
            )
        }
    }
}

/**
 * Sealed class para navegación type-safe.
 *
 * Analogía: Como un menú de restaurante donde solo puedes
 * elegir las opciones que existen, no inventar platos.
 */
sealed class Screen {
    object Home : Screen()
    object Game : Screen()
    data class Results(val correctCount: Int, val totalCount: Int) : Screen()
}