package com.educacion.domangame.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Clase principal de la base de datos.
 *
 * Analogía: Es como el edificio del banco que contiene
 * todas las cajas fuertes (tablas) y ventanillas (DAOs).
 */
@Database(
    entities = [Word::class, ChildProgress::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun wordDao(): WordDao
    abstract fun progressDao(): ProgressDao

    companion object {
        // Volatile asegura que todos los hilos vean el mismo valor
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Patrón Singleton: Solo existe UNA instancia de la base de datos.
         *
         * Analogía: Solo hay UN registro civil en tu ciudad.
         * Todos van al mismo lugar, no se crean copias.
         */
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "doman_learning_database"
                )
                    .fallbackToDestructiveMigration() // En desarrollo
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }
}