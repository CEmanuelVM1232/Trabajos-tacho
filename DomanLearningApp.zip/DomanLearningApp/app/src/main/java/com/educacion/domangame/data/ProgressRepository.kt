package com.educacion.domangame.data

import kotlinx.coroutines.flow.Flow

class ProgressRepository(private val progressDao: ProgressDao) {

    fun getProgressByChild(childName: String): Flow<List<ChildProgress>> {
        return progressDao.getProgressByChild(childName)
    }

    fun getRecentProgress(childName: String, daysAgo: Int = 7): Flow<List<ChildProgress>> {
        val startDate = System.currentTimeMillis() - (daysAgo * 24 * 60 * 60 * 1000L)
        return progressDao.getRecentProgress(childName, startDate)
    }

    suspend fun getSuccessRate(childName: String): Double {
        return progressDao.getSuccessRate(childName) ?: 0.0
    }

    suspend fun recordAttempt(
        childName: String,
        wordId: Int,
        isCorrect: Boolean,
        timeSpentMs: Long
    ) {
        val progress = ChildProgress(
            childName = childName,
            wordId = wordId,
            isCorrect = isCorrect,
            timeSpentMs = timeSpentMs
        )
        progressDao.insertProgress(progress)
    }

    suspend fun deleteProgress(childName: String) {
        progressDao.deleteProgressByChild(childName)
    }
}