package mx.edu.utng.jtoh.security01.models

data class LoginRequest(
    val email: String,
    val password: String
)